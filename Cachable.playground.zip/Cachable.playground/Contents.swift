//: Playground - noun: a place where people can play

import UIKit

protocol Cachable {}

extension UIImageView: Cachable {}

private let cacheImage = NSCache<NSString, UIImage>()

extension Cachable where Self: UIImageView {
    typealias SuccessCompletion = (Bool) -> Void
    
    func loadImage(_ urlString: String, placeHolder: UIImage?, completion: @escaping SuccessCompletion) {
        self.image = nil
        if let image = cacheImage.object(forKey: urlString as! NSString) {
            DispatchQueue.main.async { [weak self] in
                self?.image = image
                completion(true)
            }
            return
        }
        
        self.image = placeHolder
        guard let url = URL(string: urlString) else {
            completion(false)
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            if error != nil {
                completion(false)
                return
            }
            if let httpResponse = response as? HTTPURLResponse {
                if httpResponse.statusCode != 200 {
                    completion(false)
                    return
                }
            }
            guard let data = data else {
                completion(false)
                return
            }
            if let image = UIImage(data: data) {
                DispatchQueue.main.async { [weak self] in
                    cacheImage.setObject(image, forKey: urlString as! NSString)
                    self?.image = image
                    completion(true)
                }
            } else {
                completion(false)
            }
        }
        task.resume()
        
    }
}

enum APIError: Error {
    case requestFailed
    case jsonConversionFailure
    case invalidData
    case responseUnsuccessfull
    case invalidURL
    case jsonParsingFailure
}

enum Result<T> {
    case success(T)
    case error(APIError)
}

struct Downloader {
    private let session: URLSession
    
    init() {
        self.init(configuration: .default)
    }
    
    init(configuration: URLSessionConfiguration) {
        self.session = URLSession(configuration: configuration)
    }
    
    typealias JSON = [String: Any]
    typealias jsonCompletion = (Result<JSON>) -> Void
    
    func jsonTask(with request: URLRequest, completion: @escaping jsonCompletion) -> URLSessionDataTask {
        
        let task = session.dataTask(with: request) { (data, response, error) in
            guard let httpReponse = response as? HTTPURLResponse else {
                completion(.error(.requestFailed))
                return
            }
            
            if httpReponse.statusCode != 200 {
                completion(.error(.responseUnsuccessfull))
                return
            }
            
            guard let data = data else {
                completion(.error(.invalidData))
                return
            }
            
            do {
                let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! JSON
                DispatchQueue.main.async {
                    completion(.success(json))
                }
                
            } catch {
                completion(.error(.jsonConversionFailure))
                return
            }
        }
        
        return task
    }
    
}

protocol Getable {
    associatedtype T
    func get(completion: @escaping (Result<T> -> Void))
}

struct Movie {
    init(json: [String: Any]) {

    }
}

struct Service: Getable {
    typealias completionHandler = Result<[Movie?]> -> Void
    let enpoint = ""
    let downloader = Downloader()
    
    func get(completion: @autoclosure @escaping (completionHandler)) {
        guard let url = URL(string: enpoint) else {
            completionHandler(.error(.invalidURL))
            return
        }
        let request = URLRequest(url: url)
        let task = downloader.jsonTask(with: request) { result in
            DispatchQueue.main.async { [weak self] in
                switch result {
                case .error(let error):
                    completionHandler(.error(error))
                case .success(let json):
                    guard let movieArray = json["data"] as? [[String: Any]] else {
                        completionHandler(.error(.jsonParsingFailure))
                        return
                    }
                    let movies = movieArray.map { Movie(json: $0) }
                    completionHandler(.success(movies))
                }
            }
        }
        task.resume()
    }
}
